// Connect to cockroach
const Pool = require('pg').Pool;
const pool = new Pool({
  user: 'plantCareTakerUser',
  host: 'heavy-civet-13392.5xj.gcp-us-central1.cockroachlabs.cloud',
  database: 'plantCareTaker',
  password: 'FmaEEK_i_PSyhHdEFcubvg',
  port: 26257,
  ssl: true,
});
pool.connect();

/* 
Schema for the table in the database:
CREATE TABLE public.plant_data (
  light_intensity INT8 NULL,
  soil_moisture INT8 NULL,
  date_time TIMESTAMP NULL,
  rowid INT8 NOT VISIBLE NOT NULL DEFAULT unique_rowid(),
  iswatered BOOL NULL,
  CONSTRAINT plant_data_pkey PRIMARY KEY (rowid ASC)
)
*/

// Inserts light intensity, soil moisture, and current date and time into the db
const insertPlantData = async (lightIntensity, soilMoisture, isWatered) => {
  try {
    // Send data to the database with central time
    const result = await pool.query(
      "INSERT INTO plant_data (light_intensity, soil_moisture, date_time, iswatered) VALUES ($1, $2, CURRENT_TIMESTAMP AT TIME ZONE 'America/Chicago', $3)", [lightIntensity, soilMoisture, isWatered]);
    
  } catch(error) {
    throw error;
  }
}

// Get the most recent time the plant was watered
const getLastTimeWatered = async () => {
  try {
    const result = await pool.query("SELECT date_time FROM plant_data WHERE iswatered = true ORDER BY date_time DESC LIMIT 1");
    
    return (result.rows.length == 0) ? null: result.rows[0].date_time.toLocaleString();
  } catch(error) {
    throw error;
  }
}

// Get light intensity data
const getLightIntensityData = async () => {
  const result = await pool.query("SELECT light_intensity, date_time FROM plant_data ORDER BY date_time ASC");
  
  const lightIntensities = convertValues(result.rows);
 
  return lightIntensities;
}

// Get soil moisture data
const getSoilMoistureData = async () => {
  const result = await pool.query("SELECT soil_moisture, date_time FROM plant_data ORDER BY date_time ASC");
  
  const soilMoistures = convertValues(result.rows);
  return soilMoistures;
}

// Converts the cockroachDB dates into js dates and the strings into int 
const convertValues = (rows) => {
  var data = rows.map(item => (isNaN(item.light_intensity)) ? parseInt(item.soil_moisture) :
 parseInt(item.light_intensity));
  var dates = rows.map(item => new Date(item.date_time).toLocaleString());

  var dataWithDates = {'data': data, 'dates': dates};
  return dataWithDates;
}


module.exports = {
  insertPlantData,
  getLastTimeWatered,
  getLightIntensityData,
  getSoilMoistureData
}