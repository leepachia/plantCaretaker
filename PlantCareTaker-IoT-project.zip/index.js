const express = require('express');
const app = express();
const port = process.env.PORT || 3000; // Choose the port you want to run your server on
const { Client } = require('pg');

// Connect to the database
const db = require('./db.js');

app.use(express.urlencoded({extended: true}));
app.use(express.json()); 
app.use(express.static('public')); // To serve static files like CSS and images

// Set EJS as the view engine
app.set('view engine', 'ejs');
// Set the custom views directory
app.set('views', __dirname + '/views');

// Use an ejs file instead of html so that we can send info to this file
// Show home page
app.get('/', async (req, res) => {
  let lastTimeWatered = await db.getLastTimeWatered();
  res.render('home.ejs', {lastTimeWatered: lastTimeWatered});
});

// Show the sunlight page
app.get('/sunlight', async (req, res) => {
  // Render the sunlight page with the data
  res.render('sunlight.ejs');
});

// Gets the sunlight data and sends it back to the request
app.get('/sunlightData', async (req, res) => {
  var lightIntensities = await db.getLightIntensityData(); 

  res.setHeader("Content-Type", "application/json");
  res.send(JSON.stringify(lightIntensities));
});

// Gets soil moisture data and sends it back to the request
app.get('/soilMoistureData', async (req, res) => {
  var soilMoistures = await db.getSoilMoistureData();

  res.setHeader("Content-Type", "application/json");
  res.send(JSON.stringify(soilMoistures));
});

// Show the soil moisture page
app.get('/soilMoisture', async (req, res) => {
  // Render the soil moisture page with the data
  res.render('soilMoisture.ejs');
});

// Show the settings page
app.get('/settings', (req, res) => {
  res.render('settings.ejs');
});

// Will be getting plant data from client here, send it to db
app.post('/', async (req, res) => {
  await db.getLastTimeWatered();
  // Get plant data from the client
  var lightIntensity = req.body.lightIntensity;
  var soilMoisture = req.body.soilMoisture;
  var isWatered = (req.body.isWatered == 1);

  // Send the data to the database
  await db.insertPlantData(lightIntensity, soilMoisture, isWatered);
});


// Start the server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});

