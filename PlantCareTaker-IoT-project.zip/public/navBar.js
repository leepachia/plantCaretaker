// Get the burger menu from the html
var burgerMenu = document.getElementById('burger-menu');

// Get the tabs
var burgerTabs = document.getElementById('burger-tabs');

var showTabs = false;

// When the burger menu is clicked, show the tabs
burgerMenu.addEventListener("click", function() {
  burgerTabs.style.display = (showTabs) ?  'none' : 'block';
  showTabs = !showTabs;
});