let xValues = [];
let yValues = [];

// Function to set the data for the charts and make the charts
async function setData(url, chart, yAxisLabel) {
  const response = await fetch(url);
  const data = await response.json();

  xValues = data.dates;
  yValues = data.data;

  // Makes the sunlight chart
  new Chart(chart, {
    type: "line",
    data: {
      labels: xValues,
      datasets: [
        {
          fill: false,
          lineTension: 0,
          backgroundColor: "rgba(0,0,255,1.0)",
          borderColor: "rgba(0,0,255,0.1)",
          data: yValues,
        },
      ],
    },
    options: {
      legend: { display: false },
      scales: {
        xAxes: [
          {
            labels: xValues,// Set x-axis labels explicitly
            ticks: {
              autoSkip: false,
              display: false
            },
          },
        ],
        yAxes: [{ ticks: { min: 0, max: 100 } ,
                scaleLabel: {
                  display: true,
                  labelString: yAxisLabel // Label for the Y-axis
                }}],
      },
    },
  });
}
// Variables for displaying sunlight chart
var sunlightChart = document.getElementById("sunlightChart");
const sunlightUrl = "https://90f92079-807e-4f74-8dfc-f2b03cb9e658-00-g7p03k1mkj0g.janeway.replit.dev/sunlightData";
setData(sunlightUrl, sunlightChart, "Sunlight (%)");

// Variables for displaying soil moisture chart
var soilMoistureChart = document.getElementById("soilMoistureChart");
const soilMoistureUrl = "https://90f92079-807e-4f74-8dfc-f2b03cb9e658-00-g7p03k1mkj0g.janeway.replit.dev/soilMoistureData";
setData(soilMoistureUrl, soilMoistureChart, "Soil Moisture (%)");

// Function to set the data for the chart that needs both sunlight and soil moisture variables
async function setPlantDataChart(sunlightUrl, soilMoistureUrl, chart) {
  const response = await fetch(sunlightUrl);
  const sunlightData = await response.json();
  const response2 = await fetch(soilMoistureUrl);
  const soilMoistureData = await response2.json();
  
  xValues = sunlightData.dates;

  new Chart(chart, {
    type: "line",
    data: {
      labels: xValues,
      datasets: [{ 
        data: sunlightData.data,
        borderColor: "yellow",
        fill: false
      }, { 
        data: soilMoistureData.data,
        borderColor: "blue",
        fill: false
      }]
    },
    options: {
      legend: {display: false},
      scales: {
        xAxes: [
          {
            labels: xValues, // Set x-axis labels explicitly
            ticks: {
              autoSkip: false,
              display: false
            },
          },
        ],
        yAxes: [{ ticks: { min: 0, max: 100 } ,
                scaleLabel: {
                  display: true,
                  labelString: 'Soil Moisture & Sunlight (%)' // Label for the Y-axis
                }}],
      },
    }
  });
}

// Make plant data chart
var plantDataChart = document.getElementById("plantDataChart");
setPlantDataChart(sunlightUrl, soilMoistureUrl, plantDataChart);